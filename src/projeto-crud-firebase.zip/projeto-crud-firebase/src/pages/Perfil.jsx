function Perfil() {
  return (
    <div>
      <h1>Perfil do Usuário</h1>

      <p>Nome:</p>
      <input type="text" placeholder="Digite seu nome" />

      <br /><br />

      <p>Email:</p>
      <input type="email" placeholder="Digite seu email" />

      <br /><br />

      <button>Salvar</button>
      <button>Editar</button>
      <button>Excluir</button>
    </div>
  );
}

export default Perfil;