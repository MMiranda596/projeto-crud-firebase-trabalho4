import { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/config";
import { useNavigate, Link } from "react-router-dom";

function Login() {

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const navigate = useNavigate();

  async function login() {

    try {

      await signInWithEmailAndPassword(
        auth,
        email,
        senha
      );

      navigate("/perfil");

    } catch {
      alert("Erro ao logar");
    }
  }

  return (
    <div>

      <h1>Login</h1>

      <input
        placeholder="Email"
        onChange={(e)=>setEmail(e.target.value)}
      />

      <input
        type="password"
        placeholder="Senha"
        onChange={(e)=>setSenha(e.target.value)}
      />

      <button onClick={login}>
        Entrar
      </button>

      <br/>

      <Link to="/cadastro">
        Cadastrar
      </Link>

    </div>
  );
}

export default Login;