function Produtos() {
  return (
    <div>
      <h1>Cadastro de Produtos</h1>

      <p>Nome do produto:</p>
      <input type="text" placeholder="Digite o produto" />

      <br /><br />

      <p>Preço:</p>
      <input type="number" placeholder="Digite o preço" />

      <br /><br />

      <button>Cadastrar</button>
      <button>Editar</button>
      <button>Excluir</button>
    </div>
  );
}

export default Produtos;