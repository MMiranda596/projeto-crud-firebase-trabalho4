import { useState } from "react";
import { createUserWithEmailAndPassword }
from "firebase/auth";

import {
 collection,
 addDoc
} from "firebase/firestore";

import { auth, db }
from "../firebase/config";

function Cadastro() {

 const [nome,setNome] = useState("");
 const [email,setEmail] = useState("");
 const [senha,setSenha] = useState("");

 async function cadastrar() {

  try {

   const credencial =
    await createUserWithEmailAndPassword(
      auth,
      email,
      senha
    );

   await addDoc(
    collection(db,"usuarios"),
    {
      uid: credencial.user.uid,
      nome,
      email
    }
   );

   alert("Usuário cadastrado");

  } catch(error) {

   alert(error.message);

  }
 }

 return (
  <div>

   <h1>Cadastro</h1>

   <input
    placeholder="Nome"
    onChange={(e)=>setNome(e.target.value)}
   />

   <input
    placeholder="Email"
    onChange={(e)=>setEmail(e.target.value)}
   />

   <input
    type="password"
    placeholder="Senha"
    onChange={(e)=>setSenha(e.target.value)}
   />

   <button onClick={cadastrar}>
    Cadastrar
   </button>

  </div>
 );
}

export default Cadastro;