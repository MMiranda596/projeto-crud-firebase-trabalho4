import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCC0ap5D8EuEKMsJk32UesSKm0jwJA3-2g" ,
  authDomain: "projetocrud-8bbae.firebaseapp.com",  
  projectId: "projetocrud-8bbae",
  storageBucket: "projetocrud-8bbae.firebasestorage.app",
  messagingSenderId: "147475050967",
  appId: "1:147475050967:web:047954220d0c35e5435b92"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);